package base;

import java.util.Scanner;

public class Main {
	private static Scanner sc;

	public static void main(String[] args) {
		
		System.out.println("Pour lancer le serveur client tapez 1");
		System.out.println("Pour lancer le serveur admin tapez 2");
		System.out.println("Pour lancer le serveur admin SSL tapez 3");
		
		sc = new Scanner(System.in);
		String str = sc.nextLine();
		if (str.equals("1")) {
			ServeurMaitre serveurMaitre = new ServeurMaitre(ServeurMaitre.port, 1);
			serveurMaitre.manage();
		}
		else if (str.equals("2")) {
			ServeurMaitreAdmin serveurMaitreAdmin = new ServeurMaitreAdmin(ServeurMaitreAdmin.port, 1);
			serveurMaitreAdmin.manage();
		}
		else if (str.equals("3")) {
			ServeurMaitreAdminSSL serveurMaitreAdminSSL = new ServeurMaitreAdminSSL(3340, "345");
			serveurMaitreAdminSSL.manage();
		} else {
			System.out.println("Tapez sur 1, 2 ou 3");
		}
	}
}

