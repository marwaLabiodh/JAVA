package base;
import javax.xml.bind.ValidationEvent;
import javax.xml.bind.ValidationEventHandler;
import javax.xml.bind.ValidationEventLocator;

public class ListeDiffusValidationEventHandler implements ValidationEventHandler
{
	public boolean	handleEvent(ValidationEvent ve) 
	{
		if (ve.getSeverity()==ValidationEvent.FATAL_ERROR || ve .getSeverity()==ValidationEvent.ERROR) 
		{
				ValidationEventLocator  locator = ve.getLocator();
	
				System.out.println("Document de définition de formation invalide : " + locator.getURL());
				System.out.println("Erreur :" + ve.getMessage());
				System.out.println("Colonne" + locator.getColumnNumber() +",ligne"+ locator.getLineNumber());
		}
	return true;
	}
}
