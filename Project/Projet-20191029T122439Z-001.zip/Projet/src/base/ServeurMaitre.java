package base;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ServeurMaitre {
	private ServerSocket serverSocket;
    private Socket socket;
    public static final int port = 33333;
    private static final int poolSize = 10;
    private ExecutorService pool = null;
    private Boolean isFinished = false;

    /**
     *Method getter
     *
     *@return Retourne l'état du serveur, TRUE s'il a fini FALSE sinon
     */
    public Boolean getIsFinished() {
        return isFinished;
    }

    /**
     *Method setter
     *
     *@param isFinished change l'état du serveur
     */
    public void setIsFinished(Boolean isFinished) {
        this.isFinished = isFinished;
    }
    
    /**
     *Constructeur
     *
     *@param port Port sur lequel le serveur va se connecter
     *@param size Taille du port
     */
    ServeurMaitre(int port, int size) {
        try {
            serverSocket = new ServerSocket(port,size);
            pool = Executors.newFixedThreadPool(poolSize);
        } catch (IOException ex) {
            Logger.getLogger(ServeurMaitre.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void manage() {
        while (!isFinished) {
            try { 
                pool.execute(new ServeurEsclave(serverSocket.accept(),this));
            }
            catch (IOException e) {System.out.println(e);}
            finally {
                try { if (socket != null) socket.close();}
                catch (IOException e) {}
            }
        }
    }
    
    /**
     *Method getter
     *
     *@return Le socket sur lequel le serveur est connecte
     */
    public ServerSocket getServerSocket() {
        return serverSocket;
    }

    /**
     *Method setter
     *
     *@param serverSocket socket sur lequel le serveur poura se connecter
     */
    public void setServerSocket(ServerSocket serverSocket) {
        this.serverSocket = serverSocket;
    }

    /**
     *Method getter
     *
     *@return le socket utilise
     */
    public Socket getSocket() {
        return socket;
    }

    /**
     *Method setter
     *
     *@param socket Le socket qui sera utilise
     */
    public void setSocket(Socket socket) {
        this.socket = socket;
    }
    
}