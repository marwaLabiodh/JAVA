package base;
import java.net.*;
import java.util.Scanner;
import java.io.*;
import protocole.diff.*;

public class TestDiffHandler {
	private static Scanner sc;

	public static void main(String args[]){
	System.getProperties().put("java.protocol.handler.pkgs", "protocole");
	try{
		//if(args.length!=1) 
          //error("Usage: java TestURLHandler diff://nomListe:mailDiffuseur:themeListe:mdpListe@www.ig-edu.univ-paris13.fr?commande");
		
		sc = new Scanner(System.in);
		System.out.println("Quel commande voulez vous executer :");
		String str = sc.nextLine();
		
		if (str.equals("CreerListe")) {
			System.out.println("Nom de votre liste :");
			String str1 = sc.nextLine();
			
			System.out.println("Votre mail :");
			String str2 = sc.nextLine();
			
			System.out.println("Mot de passe :");
			String str3 = sc.nextLine();
			
			System.out.println("Theme :");
			String str4 = sc.nextLine();
			
			URL url = new URL("diff://"+str1+":"+str3+":"+str4+":"+str2+"?"+str);
			DiffContent diffContent = (DiffContent) url.getContent();
			
			System.out.println("nomListe : " + diffContent.getNomListe());
			System.out.println("mailDiffuseur : " + diffContent.getMailDiffuseur());
			System.out.println("themeListe : " + diffContent.getThemeListe());
			System.out.println("mdpListe : " + diffContent.getMdpListe());
		}
		else if (str.equals("SupprimerListe")) {
			System.out.println("Nom de votre liste :");
			String str1 = sc.nextLine();
			
			System.out.println("Mot de passe :");
			String str2 = sc.nextLine();
			
			URL url = new URL("diff://"+str1+":"+str2+"@toto?"+str);
			DiffContent diffContent = (DiffContent) url.getContent();
			
			System.out.println("Liste supprimé : " + diffContent.getNomListe());
			
		}
		else if (str.equals("Abonnement")) {
			System.out.println("Nom de votre liste :");
			String str1 = sc.nextLine();
			
			System.out.println("Votre email:");
			String str2 = sc.nextLine();
			
			URL url = new URL("diff://"+str1+":"+str2+"?"+str);
			DiffContent diffContent = (DiffContent) url.getContent();
			
			System.out.println("Abonnement à : " + diffContent.getNomListe());
		}
		else if (str.equals("Desabonnement")) {
			System.out.println("Nom de votre liste :");
			String str1 = sc.nextLine();
			
			System.out.println("Votre email:");
			String str2 = sc.nextLine();
			
			URL url = new URL("diff://"+str1+":"+str2+"?"+str);
			DiffContent diffContent = (DiffContent) url.getContent();
			
			System.out.println("Desabonnement à : " + diffContent.getNomListe());
		}
		else if (str.equals("EnvoiMail")) {
			System.out.println("Nom de votre liste :");
			String str1 = sc.nextLine();
			
			System.out.println("Votre sujet:");
			String str2 = sc.nextLine();
			
			System.out.println("Votre message:");
			String str3 = sc.nextLine();
			
			URL url = new URL("diff://"+str1+":"+str2+":"+str3+"?toto.fr"+str);
			DiffContent diffContent = (DiffContent) url.getContent();
			
			System.out.println("Liste : " + diffContent.getNomListe());
			System.out.println("Sujet : " + diffContent.getSujet());
			System.out.println("Message envoyé : " + diffContent.getMessage());
		}
		else if (str.equals("RecupereListe")) {
			System.out.println("Quel theme voulez vous recuperer :");
			String str1 = sc.nextLine();
			
			URL url = new URL("diff://"+str1+"?toto.fr"+str);
			DiffContent diffContent = (DiffContent) url.getContent();
			
			System.out.println("Theme : " + diffContent.getThemeListe());
		}
		else if (str.equals("Fin")) {
			System.out.println("Fin ");
		}
		else {
			System.out.println("Veuillez entrer une commande valide.");
			System.out.println("Les commandes possibles sont :");
			System.out.println("- CreerListe");
			System.out.println("- SupprimerListe");
			System.out.println("- Abonnement");
			System.out.println("- Desabonnement");
			System.out.println("- EnvoiMail");
			System.out.println("- RecupereListe");
			System.out.println("- Fin");
		}
		
		
		//URL url = new URL("diff://test:1234:COURS:toto@toto.fr?CreerListe");

		//DiffContent diffContent = (DiffContent) url.getContent();
		
		//System.out.println("nomListe : " + diffContent.getNomListe());
		//System.out.println("mailDiffuseur : " + diffContent.getMailDiffuseur());
		//System.out.println("themeListe : " + diffContent.getThemeListe());
		//System.out.println("mdpListe : " + diffContent.getMdpListe());
		
		
		
	}catch (MalformedURLException ex){ System.out.println(ex); error("Bad URL");
	}catch (IOException ex){ System.out.println(ex); error("IOException occurred."); }	
	}

	public static void error(String s){
		System.out.println(s); System.exit(1);
	}
}
