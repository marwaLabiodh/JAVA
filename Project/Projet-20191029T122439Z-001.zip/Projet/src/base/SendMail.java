package base;

import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;

public class SendMail{
	
	static Scanner sc = new Scanner(System.in);
	
	/**
	*Method qui permet d'envoyer un mail
	*
	*@param ListmailDest liste des destinataires du mail
	*@param subject sujet du mail
	*@param msg message a envoyer dans le mail
	*/
	public static void envoiMessage(List<String> ListmailDest,String subject, String msg) {
		
		try{
			
			
			for(int i=0; i<ListmailDest.size();i++) {
				Properties props = System.getProperties();
				
				props.put("mail.transport.protocol","smtp");
				props.put("mail.smtp.host","upn.univ-paris13.fr");
				
				Session session = Session.getInstance(props);
				MimeMessage message = new MimeMessage(session);
				
				
				String mailDest = ListmailDest.get(i);
				message.setFrom(new InternetAddress("test@test.fr"));
				message.setRecipient(Message.RecipientType.TO, new InternetAddress(mailDest));
				message.setSubject(subject);
				message.setText(msg);
				Transport.send(message);
				System.out.println("Message envoyer");
			}
			
			
		}catch (AddressException e){
			System.err.println(e);
		}catch (MessagingException e) {
			System.err.println(e);
		}

	}
	

}