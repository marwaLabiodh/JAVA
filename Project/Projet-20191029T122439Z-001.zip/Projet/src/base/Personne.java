package base;


public class Personne {
	private String email;
	
	public Personne(String m) {
		this.email=m;
	}
	
	public String getEmail() {
		return this.email;
	}
	
	/**
	*Methode de verification de mail
	*
	*@param m Mail que la methode va verifier
	*@return TRUE si le mail est valide FALSE sinon
	*/
	public static boolean emailValide(String m) {
		return m.matches("^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$");
	}
/*
	public static void main(String[] args) {
		Personne e = new Personne("heba.h!..@hotmail.fr");
		if(emailValide(e.getEmail())) {
			System.out.println(e.getEmail());
		}
		else {
		System.out.println("mail non valide");
		}
	}

	public void setEmail(String email) {
		this.email = email;
	}
*/	
}
