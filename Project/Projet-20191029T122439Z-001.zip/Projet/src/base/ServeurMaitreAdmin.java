package base;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServeurMaitreAdmin {
	
	private ServerSocket serverSocket;
    private Socket socket;
    public static final int port = 33330;
    private static final int poolSize = 10;
    private ExecutorService pool = null;
    private Boolean isFinished = false;

    public Boolean getIsFinished() {
        return isFinished;
    }

    public void setIsFinished(Boolean isFinished) {
        this.isFinished = isFinished;
    }
    
    ServeurMaitreAdmin(int port, int size) {
        try {
            serverSocket = new ServerSocket(port,size);
            pool = Executors.newFixedThreadPool(poolSize);
        } catch (IOException ex) {
            Logger.getLogger(ServeurMaitre.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void manage() {
        while (!isFinished) {
            try { 
                pool.execute(new ServeurEsclaveAdmin(serverSocket.accept(),this));
            }
            catch (IOException e) {System.out.println(e);}
            finally {
                try { if (socket != null) socket.close();}
                catch (IOException e) {}
            }
        }
    }
    
    public ServerSocket getServerSocket() {
        return serverSocket;
    }

    public void setServerSocket(ServerSocket serverSocket) {
        this.serverSocket = serverSocket;
    }

    public Socket getSocket() {
        return socket;
    }

    public void setSocket(Socket socket) {
        this.socket = socket;
    }
    
}
	
