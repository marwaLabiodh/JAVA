package base;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.net.Socket;
import java.security.Security;
import java.util.Scanner;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import com.sun.net.ssl.internal.ssl.Provider;

@SuppressWarnings("restriction")
public class ClientAdminSSL {
	static Scanner sc = new Scanner(System.in);
	
	private final int portHTTPS = 443;
	// port https par défaut
	private SSLSocket sslSocket;
	private String host;
	public ClientAdminSSL(String host) throws Exception {
		
		Security.addProvider(extracted());
		System.setProperty("javax.net.ssl.trustStore","jssecacerts");
		SSLSocketFactory factory = (SSLSocketFactory) SSLSocketFactory.getDefault ();
		try {
			sslSocket = (SSLSocket) factory.createSocket(host,portHTTPS);
		}
		catch
		(IOException e) {System.out.println(e);}
	}


	private Provider extracted() {
		return new com.sun.net.ssl.internal.ssl.Provider();
	}
	
	
	public void test() {
		try {
			// envoi de données
			Writer output = new OutputStreamWriter(sslSocket.getOutputStream());
			output.write("GET https://"+host+"/ HTTP 1.1\r\n\r\n");
			output.flush();
			
			// lecture de la réponse
			BufferedReader input = new BufferedReader(new InputStreamReader(sslSocket.getInputStream()));
			
			int c;
			while ((c=input.read())!=-1){System.out.write(c);}
			output.close(); input.close();
		}
		catch (IOException e) {System.out.println(e);}
	}
	
	public void close() {
		try {sslSocket.close();}
		catch (IOException e) {System.out.println(e);}
	}
	
	public static void main(String[] args) throws Exception {
		if (args.length == 0) {
			System.out.println("Usage : java ClientAdminSSL host");
			return;
	}
		ClientAdminSSL ClientAdmin = new ClientAdminSSL(args[0]);
		ClientAdmin.test();
		ClientAdmin.close();
	}
}