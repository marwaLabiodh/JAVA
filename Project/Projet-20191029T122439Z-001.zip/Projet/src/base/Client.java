package base;

// File Name GreetingClient.java
import java.net.*;
import java.io.*;
//import java.io.BufferedReader;
import java.util.Scanner;


public class Client {
	static Scanner sc = new Scanner(System.in);
	public static void main(String [] args) throws IOException{
		String NomServeur = "localhost";
		int port = 33333;
		Socket client;
		PrintWriter sortie;
	try
		{
			client = new Socket(NomServeur, port);
			System.out.println("Entrer votre commande :");
			String msg = sc.nextLine();
			sortie = new PrintWriter(client.getOutputStream());
			sortie.println(msg);
			sortie.flush();			
			System.out.println("Terminé!");
			client.close();
		}
		catch (IOException e) {
			System.out.println("Le serveur n'a pas été lancé ");
		}

	}
}