package base;
import java.io.File;

import java.util.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import liste.*;

public class GestionListe {
	
	// Pas sur : private static List<Personne> ensembleUtilisateur = new ArrayList<Personne>();
	public static List<ListeDeDiffusion> ListeDeDiffus = new ArrayList<ListeDeDiffusion>();
	
	/**
	*Fonction permet de creer une liste
	*
	*
	*/
	public static void creerListe(String nom, String mail, String mdp, String theme ) {
		Personne diffuseur = new Personne(mail);
		ListeDeDiffusion liste = new ListeDeDiffusion(nom,diffuseur, mdp, theme);
		ListeDeDiffus.add(liste);
		System.out.println("Liste crée");
	}
	
	/**
	*Fonction getter 
	*
	*@return ListeDeDiffus
	*/
	public static List<ListeDeDiffusion> getListeDeDiffus() {
		return ListeDeDiffus;
	}

	public static void setListeDeDiffus(List<ListeDeDiffusion> listeDeDiffus) {
		ListeDeDiffus = listeDeDiffus;
	}
	
	public static void afficheElementsListe() {
		for (int i=0; i< ListeDeDiffus.size(); i++) {
			System.out.println("Nom :");
			System.out.println(ListeDeDiffus.get(i).getNom());
			System.out.println("Diffuseur :");
			System.out.println(ListeDeDiffus.get(i).getDiffuseur().getEmail());
			System.out.println("Liste d'abonnés :");
			for (int j=0; j< ListeDeDiffus.get(i).getAbonnes().size(); j++) {
				System.out.println(ListeDeDiffus.get(i).getAbonnes().get(j).getEmail());
			}
			System.out.println("Theme :");
			System.out.println(ListeDeDiffus.get(i).getTheme());
			System.out.println("\n");
		} 
	}

	public static void SupprimerListe(String nom, String mdp) {
		for(int i = 0; i< ListeDeDiffus.size(); i++) {
			if(ListeDeDiffus.get(i).getNom().equals(nom) && ListeDeDiffus.get(i).getMdp().equals(mdp)) {
				ListeDeDiffus.remove(i);
				System.out.println("Liste supprimé");
			}
			else System.out.println("Nom ou mot de passe incorrecte");
		}
	}
	
	public static void AbonnementListe(String nom, String mail) {
		Personne p = new Personne(mail);
		for(int i = 0; i< ListeDeDiffus.size(); i++) {
			if(ListeDeDiffus.get(i).getNom().equals(nom) ) {
				if(! ListeDeDiffus.get(i).getAbonnes().contains(p)) {
					ListeDeDiffus.get(i).addAbonne(p);
					System.out.println("Abonné ajouté");
				}
				else System.out.println("Vous êtes déjà abonné");
			}
			else System.out.println("La liste existe pas");
		}
	}
	
	public static void desabonnementListe(String nom, String mail) {
		Personne p = new Personne(mail);
		for(int i = 0; i< ListeDeDiffus.size(); i++) {
			if(ListeDeDiffus.get(i).getNom().equals(nom)) {
				if(ListeDeDiffus.get(i).getAbonnes().contains(p)) {
					ListeDeDiffus.get(i).deleteAbonne(p);
					System.out.println("Abonné supprimé!");
				}
				else System.out.println("Vous n'êtes pas abonné");
			}
			else System.out.println("Nom ou mot de passe incorrecte");
		}
	}
	
	public static List<String> getMailAbonnes(String nom){
		List<String> listeMail = new ArrayList<String>();
		for(int i = 0; i< ListeDeDiffus.size(); i++) {
			if(ListeDeDiffus.get(i).getNom().equals(nom)) {
				List<Personne> listeAbo = new ArrayList<Personne>();
				listeAbo = ListeDeDiffus.get(i).getAbonnes();
				for(int j = 0; j< listeAbo.size(); j++) {
					if(! listeMail.contains(listeAbo.get(j).getEmail())) {
						listeMail.add(listeAbo.get(j).getEmail());
					}
				}
			}
		}
		return listeMail;			
	}
	
	public static void recupListTheme(String theme) {
		try {
			
			liste.ObjectFactory objFactory = new liste.ObjectFactory();
			
			JAXBElement<TypeListe>  uneListeJABX;
		
			JAXBContext jaxbContext = JAXBContext.newInstance("liste");
			Marshaller marshaller = jaxbContext.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, new Boolean(true));
			
			for(int i = 0; i< ListeDeDiffus.size(); i++) {
				if (ListeDeDiffus.get(i).getThemeToString().equals(theme)) {
					TypeListe typeListe = objFactory.createTypeListe();
					typeListe.setTheme(theme);
					typeListe.setNom(ListeDeDiffus.get(i).getNom());
					typeListe.setDiffuseur(ListeDeDiffus.get(i).getDiffuseur().getEmail());
					for (int j= 0; j<ListeDeDiffus.get(i).getAbonnes().size();j++) {
						typeListe.getAbonnes().add(ListeDeDiffus.get(i).getAbonnes().get(j).getEmail());
					}
					uneListeJABX = new liste.ObjectFactory().createListe(typeListe);
					marshaller.marshal(uneListeJABX, new File("src/"+theme+".xml"));
					
				}
			}
			System.out.println("Le fichier liste.xml à été généré");
			
		} catch (Exception e) {System.err.println(e);}
	}
	
	public static void SupprimerListes() {
		for(int i = 0; i< ListeDeDiffus.size(); i++) {
			ListeDeDiffus.remove(ListeDeDiffus.get(i));
		}
	}
	
	public static void SupprimerL(String nom) {
		for(int i = 0; i< ListeDeDiffus.size(); i++) {
			if(ListeDeDiffus.get(i).getNom().equals(nom)) {
				ListeDeDiffus.remove(ListeDeDiffus.get(i));
			}
		}
	}
}
