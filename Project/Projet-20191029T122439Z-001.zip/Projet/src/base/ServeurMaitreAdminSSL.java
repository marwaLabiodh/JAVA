package base;

import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ServerSocket;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.concurrent.ExecutorService;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;

public class ServeurMaitreAdminSSL {
	
	private ServerSocket serverSocket;
    private SSLServerSocket socket;
    public static final int port = 33340;
    private ExecutorService pool = null;
    private Boolean isFinished = false;

    public Boolean getIsFinished() {
        return isFinished;
    }

    public void setIsFinished(Boolean isFinished) {
        this.isFinished = isFinished;
    }
    
    ServeurMaitreAdminSSL(int port, String password) {
    	
    	// 1) spécif de la fabrique de cryptage
    	KeyManagerFactory kmf= null;
    	SSLContext context=	null;
    	try {
    		context = SSLContext.getInstance("SSLv3");
    		kmf = KeyManagerFactory.getInstance("SunX509");
    	}
    	catch (NoSuchAlgorithmException e1) { e1.printStackTrace(); }
    	
    	// 2) spécif du gestionnaire de clés
    	KeyStore ks = null;
    	try {
    		ks = KeyStore.getInstance("JKS");
    	} catch (KeyStoreException e2) { e2.printStackTrace(); }
    	
    	// 3) récupération du certificat (et de la clé)
    	char[] passPhrase = password.toCharArray();
    	try {
    		ks.load(new FileInputStream("Fichier_Certif"), passPhrase);
    	} catch (NoSuchAlgorithmException e3) { e3.printStackTrace(); }
    	catch (CertificateException e3) { e3.printStackTrace(); }
    	catch (FileNotFoundException e3) { e3.printStackTrace(); }
    	catch (IOException e3) { e3.printStackTrace(); }
    	
    	// 4) paramétrage de la fabrique de cryptage par la clé
    	try
    	{
    		kmf.init(ks, passPhrase);
    	}
    	catch (KeyStoreException e4) { e4.printStackTrace();}
    	catch (NoSuchAlgorithmException e4) { e4.printStackTrace();}
    	catch (UnrecoverableKeyException e4) { e4.printStackTrace();}
    	
    	
    	// 5) spécification du contexte de génération de SSLServerSocket
    	try {
    		context.init(kmf.getKeyManagers(),null,null);
    	} catch (KeyManagementException e5) { e5.printStackTrace();}
    	
    	
    	// 6) création de la fabrique de SSLServerSocket
    	SSLServerSocketFactory factory = context.getServerSocketFactory ();
    	
    	// 7) création d’un SSLServerSocket
    	try
    	{
    		serverSocket = (SSLServerSocket) factory.createServerSocket (ServeurMaitreAdminSSL.port);
    		System.out.println ("Création Socket OK");
    	} catch (IOException e) { 
    		System.out.println ("Erreur ServerSocket : " + e);
    		System.exit (0);
    	}
    }

   public void manage() {
        while (!isFinished) {
            try { 
                pool.execute(new ServeurEsclaveAdminSSL(serverSocket.accept(),this));
            }
            catch (IOException e) {System.out.println(e);}
            finally {
                try { if (socket != null) socket.close();}
                catch (IOException e) {}
            }
        }
    }
    
    public ServerSocket getServerSocket() {
        return serverSocket;
    }

    public void setServerSocket(ServerSocket serverSocket) {
        this.serverSocket = serverSocket;
    }

    public SSLServerSocket getSocket() {
        return socket;
    }

    /*public void setSocket(Socket socket) {
        this.socket = socket;
    }*/
    
}
	
