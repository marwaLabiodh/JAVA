package base;
import java.util.*;


public class ListeDeDiffusion {
	public static Object getAbonnes;
	public String nom;
	public Personne diffuseur;
	public String mdp;
	private static List<Personne> abonnes = new ArrayList<Personne>();
	public Theme theme;
	public static enum Theme { 
		COURS ("COURS"),
		JEUX ("JEUX"),
		SOIN ("SOIN");
		private final String theme;
		Theme(String theme) {
			this.theme=theme;
		}
	}
	
	//constructor
	/**
	*Fonction generatrice
	*
	*@param nom Nom de la liste de diffusion
	*@param diffuseur Personne qui gere la liste de diffusion
	*@param mdp Mot de passe de la liste de diffusion
	*@param theme Theme de la liste de diffusion
	*/
	
	public ListeDeDiffusion (String nom, Personne diffuseur, String mdp, String theme){
		this.nom = nom;
		this.diffuseur = diffuseur;
		this.mdp = mdp;
		this.theme = Theme.valueOf(theme);
		ListeDeDiffusion.abonnes = new ArrayList<Personne>();
	}
	
	
	/**
	*Fonction getter
	*
	*@return Nom de la liste de diffusion
	*/
	public String getNom() {
		return nom;
	}
	
	/**
	*Fonction setter
	*
	*@param nom Nom donne a la list de diffusion
	*/
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	/**
	*Fonction getter
	*
	*@return Diffiseur de la liste de diffusion
	*/
	public Personne getDiffuseur() {
		return diffuseur;
	}
	
	/**
	*Fonction setter
	*
	*@param diffuseur Diffuseur de la list de diffusion
	*/
	public void setDiffuseur(Personne diffuseur) {
		this.diffuseur = diffuseur;
	}
	
	/**
	*Fonction getter
	*
	*@return Le mot de passe de la liste de diffusion
	*/
	public String getMdp() {
		return mdp;
	}
	
	/**
	*Fonction setter
	*
	*@param mdp Accorde un mot de passe à la liste de diffusion
	*/
	public void setMdp(String mdp) {
		this.mdp = mdp;
	}
	
	/**
	*Fonction getter
	*
	*@return La liste des abonnes à une liste de diffusion
	*/
	public List<Personne> getAbonnes() {
		return abonnes;
	}	
	
	/**
	*Fonction setter
	*
	*@param abonnes Liste des personnes abonnees à une liste de diffusion
	*/
	public void setAbonnes(List<Personne> abonnes) {
		ListeDeDiffusion.abonnes = abonnes;
	}
	
	/**
	*Fonction getter
	*
	*@return Theme d'une liste de diffusion
	*/
	public Theme getTheme() {
		return theme;
	}
	
	
	public String getThemeToString() {
		return theme.toString();
	}
	
	/**
	*Fonction setter
	*
	*@param theme Theme de la liste de diffusion
	*/
	public void setTheme(Theme theme) {
		this.theme = theme;
	}
	
	
	/**
	*Methode qui ajoute un abonne a la liste des personnes abonnees a une liste de diffusion
	*
	*@param ab Personne a ajouter a la liste d'abonnes d'une liste de diffusion
	*/
	public void addAbonne(Personne ab) {
		ListeDeDiffusion.abonnes.add(ab);
	}
	
	
	/**
	*Methode qui supprime un abonne de la liste des personnes abonnees a une liste de diffusion
	*
	*@param ab Personne a supprimer de la liste d'abonnes
	*/
	public void deleteAbonne (Personne ab) {
		ListeDeDiffusion.abonnes.remove(ab);
	}
	
	
}
