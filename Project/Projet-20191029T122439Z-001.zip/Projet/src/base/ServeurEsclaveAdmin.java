package base;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

/**
*Method Override de run() de la classe Runnable
*
*/
public class ServeurEsclaveAdmin implements Runnable {
    private final Socket socket;
    private final ServeurMaitreAdmin serveur;
    
    ServeurEsclaveAdmin(Socket socket, ServeurMaitreAdmin serveur) {
        this.socket = socket;
        this.serveur = serveur;
    }
        
    @Override
    public void run() {
        try { 
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream(), "8859_1"),1024); // flux en lecture
            StringBuffer sb = new StringBuffer();
            sb.append(input.readLine());
            System.out.println(sb);
            String[] commande = sb.toString().split(" ");
            switch (commande[0]) {
                case "CreerListe": System.out.println();
                        GestionListe.creerListe(commande[1],commande[2],commande[3],commande[4]);
                    break;
                case "SupprimerListe": System.out.println();
                		GestionListe.SupprimerListe(commande[1],commande[2]);
                	break;
                case "AfficherListe": System.out.println();
        				GestionListe.afficheElementsListe();
        			break;
                case "Abonnement": System.out.println();
        				GestionListe.AbonnementListe(commande[1],commande[2]);
        			break;  
                case "Desabonnement": System.out.println();
        				GestionListe.desabonnementListe(commande[1],commande[2]);
        			break; 
                case "EnvoiMail": System.out.println();
                		SendMail.envoiMessage(GestionListe.getMailAbonnes(commande[1]),commande[2],commande[3]);
    				break; 
                case "RecupereListe": System.out.println();
                		GestionListe.recupListTheme(commande[1]);
    				break; 
    			case "SupprimerListes": System.out.println();
                		GestionListe.SupprimerListes();
    				break; 
    			case "SupprimerL": System.out.println();
        				GestionListe.SupprimerL(commande[1]);
        			break; 
                case "Fin": serveur.setIsFinished(true);
                    break;
                default: ;
            }
        }
        catch (IOException e) {System.out.println(e);}
        finally {
            try { if (socket != null) socket.close();}
            catch (IOException e) {}
        }
    }
    
    
} 