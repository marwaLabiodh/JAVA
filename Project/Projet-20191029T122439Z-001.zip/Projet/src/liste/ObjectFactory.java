//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.2.8-b130911.1802 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2019.04.12 à 03:10:40 PM CEST 
//


package liste;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the liste package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Liste_QNAME = new QName("", "Liste");
    private final static QName _Diffuseur_QNAME = new QName("", "diffuseur");
    private final static QName _Theme_QNAME = new QName("", "Theme");
    private final static QName _Abonnes_QNAME = new QName("", "abonnes");
    private final static QName _Nom_QNAME = new QName("", "nom");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: liste
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link TypeListe }
     * 
     */
    public TypeListe createTypeListe() {
        return new TypeListe();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TypeListe }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Liste")
    public JAXBElement<TypeListe> createListe(TypeListe value) {
        return new JAXBElement<TypeListe>(_Liste_QNAME, TypeListe.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "diffuseur")
    public JAXBElement<String> createDiffuseur(String value) {
        return new JAXBElement<String>(_Diffuseur_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Theme")
    public JAXBElement<String> createTheme(String value) {
        return new JAXBElement<String>(_Theme_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "abonnes")
    public JAXBElement<String> createAbonnes(String value) {
        return new JAXBElement<String>(_Abonnes_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "nom")
    public JAXBElement<String> createNom(String value) {
        return new JAXBElement<String>(_Nom_QNAME, String.class, null, value);
    }

}
