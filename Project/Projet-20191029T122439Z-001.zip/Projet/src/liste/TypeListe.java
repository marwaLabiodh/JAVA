//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.2.8-b130911.1802 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2019.04.12 à 03:10:40 PM CEST 
//


package liste;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour typeListe complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="typeListe">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{}nom"/>
 *         &lt;element ref="{}diffuseur"/>
 *         &lt;element ref="{}abonnes" maxOccurs="unbounded"/>
 *         &lt;element ref="{}Theme"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "typeListe", propOrder = {
    "nom",
    "diffuseur",
    "abonnes",
    "theme"
})
public class TypeListe {

    @XmlElement(required = true)
    protected String nom;
    @XmlElement(required = true)
    protected String diffuseur;
    @XmlElement(required = true)
    protected List<String> abonnes;
    @XmlElement(name = "Theme", required = true)
    protected String theme;

    /**
     * Obtient la valeur de la propriété nom.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNom() {
        return nom;
    }

    /**
     * Définit la valeur de la propriété nom.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNom(String value) {
        this.nom = value;
    }

    /**
     * Obtient la valeur de la propriété diffuseur.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDiffuseur() {
        return diffuseur;
    }

    /**
     * Définit la valeur de la propriété diffuseur.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDiffuseur(String value) {
        this.diffuseur = value;
    }

    /**
     * Gets the value of the abonnes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the abonnes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAbonnes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getAbonnes() {
        if (abonnes == null) {
            abonnes = new ArrayList<String>();
        }
        return this.abonnes;
    }

    /**
     * Obtient la valeur de la propriété theme.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTheme() {
        return theme;
    }

    /**
     * Définit la valeur de la propriété theme.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTheme(String value) {
        this.theme = value;
    }

}
