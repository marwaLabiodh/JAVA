// DiffContentHandler.java
//
// gestionnaire de contenu pour le protocole monDiff

package protocole.diff;
import java.net.*;

import base.*;

import java.io.*;


public class DiffContentHandler extends ContentHandler {

	String nomListe ="";
	String mailDiffuseur="";
	String themeListe="";
	String mdpListe="";
	String commande="";
	String sujet="";
	String mail="";

	
	
	public Object getContent(URLConnection urlc) throws IOException {
		
		
		URL url = urlc.getURL();
		String[] userInfo = url.getUserInfo().split(":");
		
		commande = url.getQuery();
		
		if (commande.equals("CreerListe")) {
			String mail = userInfo[3]+"@"+url.getHost();
			GestionListe.creerListe(userInfo[0],mail,userInfo[1],userInfo[2]);
			return new DiffContent(userInfo[0],mail,userInfo[2],userInfo[1],"","",commande);
		}
		else if (commande.equals("SupprimerListe")) {
			GestionListe.SupprimerListe(userInfo[0], userInfo[1]);
			return new DiffContent(userInfo[0],"","",userInfo[1],"","",commande);
		}
		else if (commande.equals("Abonnement") ) {
			String mail = userInfo[1]+"@"+url.getHost();
			GestionListe.AbonnementListe(userInfo[0], mail);
			return new DiffContent(userInfo[0],mail,"","","","",commande);
		}
		else if (commande.equals("Desabonnement") ) {
			String mail = userInfo[1]+"@"+url.getHost();
			GestionListe.desabonnementListe(userInfo[0], mail);
			return new DiffContent(userInfo[0],mail,"","","","",commande);
		}
		else if (commande.equals("EnvoiMail") ) {	
			SendMail.envoiMessage(GestionListe.getMailAbonnes(userInfo[0]),userInfo[1],userInfo[2]);
			return new DiffContent(userInfo[0],"","","",userInfo[1],userInfo[2],commande);
		}
		else if (commande.equals("RecupereListe")) {
			GestionListe.recupListTheme(userInfo[0]);
			return new DiffContent("","",userInfo[0],"","","",commande);
		}
		else {
			return null;
		}
	}

	

	public static void error(String s){
		System.out.println(s); System.exit(1);
	}
}
