
/** 
 * Une connection URL pour le protocole FTP (une partie).
 *
 * <p>La syntaxe d'une URL FTP est :
 *
 * <pre>
 * ftp:&lt;url&gt;?{commande}
 * </pre>
 *
 * <p>par exemple :
 *
 * <p><code>
 * ftp://univ-paris13.fr?fichier<br>
 * </code>
 *
 * 
 * <p>Exemple d'utilisation dans un code :
 *
 * <pre>
 * URL url = new URL("ftp://www.univ-paris13.fr?fichier");
 * FTPURLConnection ftpConnection = (FTPURLConnection)url.openConnection();
 * FTPContent ftpContent = ftpConnection.getContent();
 * </pre>
 *
 */

package protocole.diff;

import java.net.*;
import java.io.*;

public class DiffURLConnection extends URLConnection {

    public DiffURLConnection(URL url) throws MalformedURLException {
		super(url);
		setContentHandlerFactory(new DiffContentHandlerFactory());
    }	

	public void connect() {
	}

   public InputStream getInputStream() {
		return null;
   }

   public String getHeaderField(String name) {
	if (name.equals("content-type")) return "diff";
	return null;
    }

}







