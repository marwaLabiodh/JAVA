// FTPContent.java
//
// structure définissant un contenu obtenu par FTP
// champs :
//		- String login
//		- String passwd
//		- String machine
//		- String nomFichier
//		- String contenuFichier

package protocole.diff;

public class DiffContent {
	private String nomListe="";
	private String mailDiffuseur="";
	private String themeListe="";
	private String mdpListe="";
	private String commande="";
	private String sujet="";
	private String message="";

	public DiffContent (String nomListe,String mailDiffuseur,String themeListe,String mdpListe,String sujet,String message,String commande) {
		this.nomListe = nomListe;
		this.mailDiffuseur = mailDiffuseur;
		this.themeListe = themeListe;
		this.mdpListe = mdpListe;
		this.commande = commande;
		this.sujet = sujet;
		this.message = message;
	}

	public String getNomListe() {
		return nomListe;
	}

	public void setNomListe(String nomListe) {
		this.nomListe = nomListe;
	}

	public String getMailDiffuseur() {
		return mailDiffuseur;
	}

	public void setMailDiffuseur(String mailDiffuseur) {
		this.mailDiffuseur = mailDiffuseur;
	}

	public String getThemeListe() {
		return themeListe;
	}

	public void setThemeListe(String themeListe) {
		this.themeListe = themeListe;
	}

	public String getMdpListe() {
		return mdpListe;
	}

	public void setMdpListe(String mdpListe) {
		this.mdpListe = mdpListe;
	}

	public String getCommande() {
		return commande;
	}

	public void setCommande(String commande) {
		this.commande = commande;
	}
	
	public String getSujet() {
		return sujet;
	}

	public void setSujet(String sujet) {
		this.sujet = sujet;
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	

}
