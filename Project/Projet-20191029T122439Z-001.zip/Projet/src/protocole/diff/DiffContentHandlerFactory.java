
package protocole.diff;
import java.net.*;

class DiffContentHandlerFactory implements ContentHandlerFactory {
	public DiffContentHandlerFactory() { 
	}

	public ContentHandler createContentHandler(String mimeType) {
		return new DiffContentHandler();
	}
}
